package org.example.cm.exer2
//k tipo de chaves
//v tipo de valor
class Cache<K : Any, V : Any> {     //any faz com que k e v nao possam ser nulos
    //mapa que se pode alterar
    private val data = mutableMapOf<K, V>()
    //vai guardar o valor da cache
    fun put(key: K, value: V) {
        data[key] = value
    }
    //busca o um valor apartir da chave e devolve o valor
    fun get(key: K): V? {  //pode devolver nulo
        return data[key]
    }
    //remove um valor associado da chave
    fun evict(key: K) {
        data.remove(key)
    }
    //devolve o numero de elementos guardados
    fun size(): Int {
        return data.size
    }

    fun getOrPut(key: K, default: () -> V): V {
        if (data.containsKey(key)) {    //se ja existir a chave devolve o seu valor
            return data[key]!!  //nao pode devolver nulo
        }

        val value = default()  //default serve como um valor de reserva caso a chave nao exista
        data[key] = value      //se nao existir cria o e devolve valor default
        return value
    }
    //troca o valor de uma chave
    fun transform(key: K, action: (V) -> V): Boolean {      //recebo valor atual devolve o novo
        if (data.containsKey(key)) {
            data[key] = action(data[key]!!)
            return true     //se o valor se alterar retorna true
        }

        return false        //se o valor nao alterar retorna false
    }

    //devolve uma copia da cache
    fun snapshot(): Map<K, V> {
        return data.toMap()
    }
    //filtra o que vai devolver(>1 , so devolver chaves com valor maior que 1)
    fun filterValues(predicate: (V) -> Boolean): Map<K, V> {
        return data.filterValues(predicate).toMap()
    }
}

fun main() {
    //teste em que chave -> string e valor -> int
    val wordCache = Cache<String, Int>()

    println("--- Word frequency cache ---")

    wordCache.put("kotlin", 1)
    println("Size: ${wordCache.size()}")

    println("Frequency of kotlin: ${wordCache.get("kotlin")}")

    wordCache.getOrPut("java") { 0 }
    wordCache.getOrPut("kotlin") { 100 }

    println("getOrPut java: ${wordCache.get("java")}")
    println("getOrPut kotlin: ${wordCache.get("kotlin")}")

    val transformed = wordCache.transform("kotlin") { value ->
        value + 1
    }

    println("Transform kotlin (+1): $transformed")
    println("After transform: ${wordCache.snapshot()}")

    val filtered = wordCache.filterValues { value ->
        value >= 1
    }

    println("Filtered values >= 1: $filtered")

    println()
    println("--- Id registry cache ---")
    //teste tipo id->int e nome->string
    val idCache = Cache<Int, String>()

    idCache.put(1, "Alice")
    idCache.put(2, "Bob")

    println("Id 1: ${idCache.get(1)}")
    println("Id 2: ${idCache.get(2)}")

    idCache.evict(1)

    println("After evict id 1, size: ${idCache.size()}")
    println("Id 1 after evict: ${idCache.get(1)}")
}