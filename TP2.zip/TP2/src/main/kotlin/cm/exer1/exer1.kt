package org.example.cm.exer1
//conjunto fechado, onde os unicos eventos possiveis sao login, purchase, logout
sealed class Event {
//login
    data class Login(
        val username: String,   //nome
        val timestamp: Long     //tempo do momento
    ) : Event()
//compra
    data class Purchase(
        val username: String,   //nome
        val amount: Double,     //gasto
        val timestamp: Long     //tempo do momento
    ) : Event()
//logout
    data class Logout(
        val username: String,   //nome
        val timestamp: Long     //tempo do momento
    ) : Event()
}

//vai devolver os eventos de cada utilizador dentro da lista de eventos possiveis
fun List<Event>.filterByUser(username: String): List<Event> {
    return this.filter { event ->   //filter percorre a lista de apenas eventos possiveis
        when (event) {  //se o evento for_____ , devolve os eventos de cada utilizador
            is Event.Login -> event.username == username
            is Event.Purchase -> event.username == username
            is Event.Logout -> event.username == username
        }
    }
}

//calcula o gasto de cada utilizador
fun List<Event>.totalSpent(username: String): Double {
    return this
        .filterByUser(username)     //percorre os eventos de cada utilizador
        .filterIsInstance<Event.Purchase>()     //fica apenas com o evento de compra
        .sumOf { it.amount }        //soma todas as compras
}

//apenas vai processar os eventos
fun List<Event>.processEvents(handler: (Event) -> Unit) {
    for (event in this) {
        handler(event)      //recebe cada evento, e processa mas nao devolve nada
    }
}

fun main() {
//lista de eventos
    val events = listOf(
        Event.Login("alice", 1000),
        Event.Purchase("alice", 45.99, 1100),
        Event.Purchase("bob", 19.99, 1200),
        Event.Logout("bob", 1250),
        Event.Purchase("alice", 5.50, 1300),
        Event.Login("bob", 1400),
        Event.Logout("bob", 1500)
    )
//processa cada evento da lista
    events.processEvents { event ->
        when (event) {
            is Event.Login -> {     //se for login imprime mensagem de login
                println("[LOGIN] ${event.username} logged in at t=${event.timestamp}")
            }

            is Event.Purchase -> {  //se for purchase imprime mensagem de purchase
                println("[PURCHASE] ${event.username} spent $${event.amount} at t=${event.timestamp}")
            }

            is Event.Logout -> {    //se for logout imprime mensagem de logout
                println("[LOGOUT] ${event.username} logged out at t=${event.timestamp}")
            }
        }
    }

    println()       //total gasto por cada utilizador
    println("Total spent by alice: $${events.totalSpent("alice")}")
    println("Total spent by bob: $${events.totalSpent("bob")}")

    println()   //apenas os eventos da alice
    println("Events for alice:")
    println(events.filterByUser("alice"))
}