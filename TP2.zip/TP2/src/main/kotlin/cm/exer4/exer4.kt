package org.example.cm.exer4

import kotlin.math.sqrt
//coordenadas x e y
data class Vec2(val x: Double, val y: Double) : Comparable<Vec2> {  //compara vetores
    //soma de dois vetores
    operator fun plus(other: Vec2): Vec2 {
        return Vec2(x + other.x, y + other.y)
    }
    //subtracao de dois vetores
    operator fun minus(other: Vec2): Vec2 {
        return Vec2(x - other.x, y - other.y)
    }
    //multiplicacao de dois vetores
    operator fun times(value: Double): Vec2 {
        return Vec2(x * value, y * value)
    }
    //troca o sinal das coordenadas
    operator fun unaryMinus(): Vec2 {
        return Vec2(-x, -y)
    }
    //compara os vetores atraves do seu comprimento
    override fun compareTo(other: Vec2): Int {
        return magnitude().compareTo(other.magnitude())
    }
    //calcula o comprimento do vetor
    fun magnitude(): Double {
        return sqrt(x * x + y * y)
    }
    //calculo do produto escalar
    fun dot(other: Vec2): Double {
        return x * other.x + y * other.y
    }
    //calcula o vetor unitario
    fun normalized(): Vec2 {
        val m = magnitude() //calcula o comprimento

        if (m == 0.0) { //se o vetor fosse de 0
            throw IllegalStateException("Zero vector")
        }
        //se nao for dividde x e y pela magnitude
        return Vec2(x / m, y / m)
    }
}
//faz a multiplicacao ao contrario
operator fun Double.times(vec: Vec2): Vec2 {
    return Vec2(this * vec.x, this * vec.y)
}

fun main() {
    //lista de vetores
    val a = Vec2(3.0, 4.0)
    val b = Vec2(1.0, 2.0)

    println("a = $a")
    println("b = $b")

    println("a + b = ${a + b}")
    println("a - b = ${a - b}")
    println("a * 2.0 = ${a * 2.0}")
    println("2.0 * a = ${2.0 * a}")
    println("-a = ${-a}")

    println("|a| = ${a.magnitude()}")
    println("dot(a, b) = ${a.dot(b)}")
    println("norm(a) = ${a.normalized()}")

    println("a > b = ${a > b}")
    println("a < b = ${a < b}")
    println("a == b = ${a == b}")

    val vectors = listOf(
        Vec2(1.0, 8.0),
        Vec2(3.0, 4.0),
        Vec2(0.0, 2.0)
    )

    println("Longest = ${vectors.maxOrNull()}") //ve qual o maior comprimento
    println("Shortest = ${vectors.minOrNull()}")//ve qual o menor comprimento
}