package org.example.cm.exer3

class Pipeline {

    private val etapas = mutableListOf<Pair<String, (List<String>) -> List<String>>>()
    //adicionar etapas ao pipeline
    fun adicionarEtapa(nome: String, transformacao: (List<String>) -> List<String>) {
        etapas.add(nome to transformacao)   //nome é nome da etapa, transformação é mudanca de etapa
    }
    //executa o pipeline
    fun executar(entrada: List<String>): List<String> {
        var resultado = entrada //guarda a lista na variavel resultado

        for ((_, transformacao) in etapas) {     //vai aplicar a etapa atual a anterior
            resultado = transformacao(resultado)
        }

        return resultado
    }
    //serve para mostrar as etapas do pipeline
    fun descrever() {
        println("Pipeline stages:")

        etapas.forEachIndexed { index, etapa ->
            println("${index + 1}. ${etapa.first}")
        }
    }
}
//cria um pipeline, e vai executar como se tivesse na classe
fun buildPipeline(config: Pipeline.() -> Unit): Pipeline {      //lambda receiver
    val pipeline = Pipeline()
    pipeline.config()   //configura o pipeline
    return pipeline     //e devolve o pipeline
}

fun main() {
    //lista inical
    val logs = listOf(
        " INFO: server started ",
        " ERROR: disk full ",
        " DEBUG: checking config ",
        " ERROR: out of memory ",
        " INFO: request received ",
        " ERROR: connection timeout "
    )

    val pipeline = buildPipeline {
        //remove os espaços no inicio e final
        adicionarEtapa("Trim") { linhas ->
            linhas.map { linha ->
                linha.trim()
            }
        }
        //filtra e apenas fica as linhas que tem error
        adicionarEtapa("Filter errors") { linhas ->
            linhas.filter { linha ->
                linha.contains("ERROR")
            }
        }
        //vai transfomrar tudo em maiusculas
        adicionarEtapa("Uppercase") { linhas ->
            linhas.map { linha ->
                linha.uppercase()
            }
        }
        //adiciona a cada linha uma enumeracao
        adicionarEtapa("Add index") { linhas ->
            linhas.mapIndexed { index, linha ->
                "${index + 1}. $linha"
            }
        }
    }
    //mostra as etapas
    pipeline.descrever()

    println()
    println("Result:")
    //executa a lista logs
    val resultado = pipeline.executar(logs)
    //vai imprimir cada linha
    resultado.forEach { linha ->
        println(linha)
    }
}